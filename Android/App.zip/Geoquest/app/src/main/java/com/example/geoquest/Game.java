package com.example.geoquest;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class Game extends AppCompatActivity implements OnMapReadyCallback, LocationListener {
    protected FusedLocationProviderClient client;
    protected LocationManager locationManager;
    protected Location myLocation;
    protected RequestQueue requestQueue;
    protected SharedPreferences prefs;
    protected SharedPreferences.Editor edit;

    GoogleMap googleMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        prefs = this.getSharedPreferences("settings", Context.MODE_PRIVATE);
        requestQueue = Volley.newRequestQueue(getApplicationContext());
        Button placeButton = findViewById(R.id.mamboButton);
        placeButton.setOnClickListener(view -> {
            Intent intent = new Intent(this, PlaceList.class);
            startActivity(intent);
        });

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.google_map);
        mapFragment.getMapAsync(this);

    }

    private Location getCurrentLocation() {
        if (ActivityCompat.checkSelfPermission(this, ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(Game.this,
                    new String[]{ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 44);
        }
        return locationManager.getLastKnownLocation(locationManager.getBestProvider(new Criteria(), false));
    }
    private void whereAmI() {
        LatLng latLng = new LatLng(myLocation.getLatitude()
                ,myLocation.getLongitude());
        MarkerOptions options = new MarkerOptions().position(latLng)
                .title("Está aqui").icon(BitmapFromVector(getApplicationContext(), R.drawable.ic_baseline_person_outline_24));;
        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 20));
        googleMap.addMarker(options);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 44) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getCurrentLocation();
            }
        }
    }

    private void placeMarkers() {
        String url = "http://10.0.2.2:7000/locais";
        edit = prefs.edit();
        Set<String> locaisSet = new HashSet<>();

        StringRequest request = new StringRequest(Request.Method.GET, url, response -> {
            try {
                response = new String(response.getBytes("ISO-8859-1"), "UTF-8");
                Log.i("Resp", response);
                JSONArray jsonArray = new JSONArray(response);
                for(int i=0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    double latitude = jsonObject.getDouble("latitude");
                    double longitude = jsonObject.getDouble("longitude");
                    String name = jsonObject.getString("locationName");
                    locaisSet.add(name);
                    Log.i("Lat", String.valueOf(latitude));
                    Log.i("Long", String.valueOf(longitude));
                    showMarker(latitude, longitude, name);
                }
                edit.putStringSet("locaisSet", locaisSet);
                edit.commit();
            } catch (UnsupportedEncodingException | JSONException e) {
                e.printStackTrace();
            }

        }, error -> Log.e("Error", error.toString()));

        requestQueue.add(request);
    }

    private void showMarker(double latitude, double longitude, String name) {
        LatLng latLng = new LatLng(latitude
                ,longitude);
        MarkerOptions options = new MarkerOptions().position(latLng)
                .title(name).icon(BitmapFromVector(getApplicationContext(), R.drawable.ic_baseline_flag_24));
        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 10));

        googleMap.addMarker(options);
    }

    private BitmapDescriptor BitmapFromVector(Context context, int vectorResId) {
        Drawable vectorDrawable = ContextCompat.getDrawable(context, vectorResId);
        vectorDrawable.setBounds(0, 0, vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight());
        Bitmap bitmap = Bitmap.createBitmap(vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        vectorDrawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }

    @Override
    public void onLocationChanged(@NonNull Location location) {
        myLocation = location;
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        this.googleMap = googleMap;
        client = LocationServices.getFusedLocationProviderClient(this);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(Game.this,
                    new String[]{ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 44);
            return;
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
        myLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        Log.i("Loc", myLocation.toString());
        placeMarkers();
        whereAmI();

    }
}
