package com.example.geoquest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Gamemodes extends AppCompatActivity {
    private Button shortgame;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gamemodes);

        shortgame = (Button) findViewById(R.id.startshortgame);
        shortgame.setOnClickListener(view -> openGame());
    }

    public void openGame() {
        Intent intent = new Intent(Gamemodes.this,Game.class);
        startActivity(intent);
    }
}