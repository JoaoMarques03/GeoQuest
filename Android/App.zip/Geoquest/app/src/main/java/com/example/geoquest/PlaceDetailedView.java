package com.example.geoquest;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.HashSet;
import java.util.Set;

public class PlaceDetailedView extends AppCompatActivity {
    SharedPreferences prefs;
    SharedPreferences.Editor edit;
    RequestQueue requestQueue;
    String name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place_detailed_view);
        prefs = this.getSharedPreferences("settings", Context.MODE_PRIVATE);
        name = prefs.getString("placeName", "");
        requestQueue = Volley.newRequestQueue(this);
        populate();

    }

    protected void populate() {
        ImageView imageView = findViewById(R.id.imageView);
        String url = "http://10.0.2.2:7000/locais/" + name;

        StringRequest request = new StringRequest(Request.Method.GET, url, response -> {
            try {
                response = new String(response.getBytes("ISO-8859-1"), "UTF-8");
                Log.i("Resp", response);
                JSONObject jsonObject = new JSONObject(response);
                String imgId = jsonObject.getString("id");
                String url2 = "http://10.0.2.2:7000/foto/id/" + imgId;
                StringRequest request3 = new StringRequest(Request.Method.GET, url2, response3 -> {
                    try {
                        response3 = new String(response3.getBytes("ISO-8859-1"), "UTF-8");
                        JSONObject jsonObject1 = new JSONObject(response3);
                        String imgUrl = jsonObject1.getString("imageUrl");
                        ImageRequest req2 = new ImageRequest(
                                imgUrl,
                                response2 -> {
                                    imageView.setImageBitmap(response2);
                                },
                                0,
                                0, ImageView.ScaleType.CENTER_CROP, null, null);
                        TextView textView = findViewById(R.id.textView);
                        textView.setText(name);
                        requestQueue.add(req2);

                    } catch (UnsupportedEncodingException | JSONException e) {
                        e.printStackTrace();
                    }

                }, error -> Log.e("Error", error.toString()));

                requestQueue.add(request3);
            } catch (UnsupportedEncodingException | JSONException e) {
                e.printStackTrace();
            }

        }, error -> Log.e("Error", error.toString()));

        requestQueue.add(request);
    }
}