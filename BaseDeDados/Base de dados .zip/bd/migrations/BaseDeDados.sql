create table users (
    user_id SERIAL NOT NULL CONSTRAINT users_pkey PRIMARY KEY,
    username VARCHAR NOT NULL,
    password VARCHAR NOT NULL,
    email VARCHAR NOT NULL,
    stride_length DECIMAL (2,2) NOT NULL
);

-- Add categories users
comment on column users.user_id is 'The user''s id';
comment on column users.username is 'The user''s username';
comment on column users.password is 'The user''s password';
comment on column users.email is 'The user''s email';
comment on column users.stride_length is 'The user''s stride length';

create table quests (
    quest_id SERIAL NOT NULL CONSTRAINT quest_pkey PRIMARY KEY,
    gamemode VARCHAR NOT NULL
);

-- Add categories quests
comment on column quests.quest_id is 'The quest''s id';
comment on column quests.gamemode is 'The gamemode being played';

create table locations (
    location_id SERIAL NOT NULL CONSTRAINT locations_pkey PRIMARY KEY,
    location_name VARCHAR NOT NULL,
    longitude DECIMAL NOT NULL,
    latitude DECIMAL NOT NULL,
    name VARCHAR NULL
);

-- Add categories locations
comment on column locations.location_id is 'The location''s id';
comment on column locations.longitude is 'The locations''s longitude';
comment on column locations.latitude is 'The location''s latitude';
comment on column locations.name is 'The location''s name';

create table photos (
    photo_id SERIAL NOT NULL CONSTRAINT photos_pkey PRIMARY KEY,
    image_url VARCHAR NOT NULL,
    photo_location_id  VARCHAR NULL
);

-- Add categories photos
comment on column photos.photo_id is 'The photo''s id';
comment on column photos.image_url is 'The image''s url';
comment on column photos.photo_location_id is 'The id of the location on the photo';

create table quest_location (
    quest_location_id SERIAL NOT NULL CONSTRAINT quest_location_pkey PRIMARY KEY,
    locations_id INT REFERENCES locations (location_id) ON UPDATE CASCADE ON DELETE CASCADE,
    quests_id INT REFERENCES quests (quest_id) ON UPDATE CASCADE ON DELETE CASCADE
);

-- Add categories quest_location
comment on column quest_location.quest_location_id is 'The id of location in the quest being played';
comment on column quest_location.locations_id is 'The location''s id';
comment on column quest_location.quests_id is 'The quest''s id';

create table user_quest (
    user_quest_id SERIAL NOT NULL CONSTRAINT user_quest_pkey PRIMARY KEY,
    quests_id INT REFERENCES quests (quest_id) ON UPDATE CASCADE ON DELETE CASCADE,
    users_id INT REFERENCES users (user_id) ON UPDATE CASCADE ON DELETE CASCADE,
    locations_found integer,
    distance_covered integer,
    score integer,
    steps integer
);

-- Add categories user_quest
comment on column user_quest.user_quest_id is 'The user''s id associated with the quest''s id';
comment on column user_quest.quests_id is 'The quest''s id';
comment on column user_quest.users_id is 'The user''s id';
comment on column user_quest.locations_found is 'The number of locations found during the quest';
comment on column user_quest.distance_covered is 'The user''s distance covered during the quest';
comment on column user_quest.score is 'The user''s score during the quest';
comment on column user_quest.steps is 'The user''s steps during the quest';


insert into users (username, password, email, stride_length) values ('Joao', '123', 'joao@gmail.com', 0.9);
insert into users (username, password, email, stride_length) values ('Roberta', '123', 'roberta@gmail.com', 0.6);
insert into locations (location_name, latitude, longitude) values ('Museu do Oriente', 38.7031010386998, -9.171026243031786);
insert into locations (location_name, latitude, longitude) values ('Museu Nacional de Arte Antiga', 38.70495139178823, -9.161488308271545);
insert into locations (location_name, latitude, longitude) values ('Jardim 9 de Abril', 38.704444, -9.162722);
insert into locations (location_name, latitude, longitude) values ('Museu da Marioneta', 38.70810028885371, -9.155775935408098);
insert into locations (location_name, latitude, longitude) values ('Jardim Lisboa Antiga', 38.711817422588005, -9.154456254923248);
insert into locations (location_name, latitude, longitude) values ('Time Out Market Lisboa', 38.70722497680704, -9.145978830266364);
insert into locations (location_name, latitude, longitude) values ('Museu das Comunicações', 38.70792824352956, -9.15043129703937);
insert into locations (location_name, latitude, longitude) values ('Green Street Lisbon', 38.709267780011, -9.152416131917786);
insert into locations (location_name, latitude, longitude) values ('Museu da Farmácia', 38.71025985761974, -9.147164337525124);
insert into locations (location_name, latitude, longitude) values ('Praça Luís de Camões', 38.71074544864401, -9.143452124801652);

insert into photos (image_url, photo_location_id) values ('https://upload.wikimedia.org/wikipedia/commons/thumb/2/2b/Museu_do_Oriente.jpg/300px-Museu_do_Oriente.jpg', 1);
insert into photos (image_url, photo_location_id) values ('https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/MNAA.jpg/300px-MNAA.jpg', 2);
insert into photos (image_url, photo_location_id) values ('https://www.playocean.net/i/portugal/lisboa/jardins/jardim-9-de-abril/jardim-9-de-abril-1.jpg', 3);
insert into photos (image_url, photo_location_id) values ('https://www.playocean.net/i/portugal/lisboa/museus/museu-da-marioneta/museu-da-marioneta-1.jpg', 4);
insert into photos (image_url, photo_location_id) values ('https://www.playocean.net/i/portugal/lisboa/jardins/jardim-lisboa-antiga/jardim-lisboa-antiga-1.jpg', 5);
insert into photos (image_url, photo_location_id) values ('https://www.timeoutmarket.com/lisboa/wp-content/themes/timeout/img/fachada_empresas.jpg', 6);
insert into photos (image_url, photo_location_id) values ('https://www.e-cultura.pt/images/user/image14903760827708.jpg', 7);
insert into photos (image_url, photo_location_id) values ('https://scontent.flis6-1.fna.fbcdn.net/v/t1.6435-9/116639233_10159114608985992_3451349591373384126_n.jpg?_nc_cat=101&ccb=1-7&_nc_sid=8bfeb9&_nc_ohc=NAYvc92ItqsAX_Vk1v2&_nc_ht=scontent.flis6-1.fna&oh=00_AfAuVMs5GpnB8-wMYn1RDXABCFGhiwx2XegM5k3ehsiS_w&oe=63DE4E10', 8);
insert into photos (image_url, photo_location_id) values ('https://www.agendalx.pt/content/uploads/2021/02/Farmacia-1.jpg', 9);
insert into photos (image_url, photo_location_id) values ('https://upload.wikimedia.org/wikipedia/commons/thumb/4/41/Lisbon_10064_Lisboa_Pra%C3%A7a_Lu%C3%ADs_de_Cam%C3%B5es_2006_Luca_Galuzzi.jpg/800px-Lisbon_10064_Lisboa_Pra%C3%A7a_Lu%C3%ADs_de_Cam%C3%B5es_2006_Luca_Galuzzi.jpg', 10);