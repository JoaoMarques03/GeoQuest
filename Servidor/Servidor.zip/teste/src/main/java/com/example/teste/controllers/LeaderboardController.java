package com.example.teste.controllers;

import com.example.teste.models.UserQuest;
import com.example.teste.models.repository.LeaderboardRepository;
import com.example.teste.models.requests.LeaderboardEntry;
import com.example.teste.models.requests.Message;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/leaderboard")
@AllArgsConstructor
public class LeaderboardController {
    final LeaderboardRepository leaderboardRepository;

    @GetMapping()
    public List<UserQuest> getAll() {
        return leaderboardRepository.getLeaderboard();
    }

    @PostMapping()
    public Message addEntry(@RequestBody LeaderboardEntry leaderboardEntry) {
        UserQuest userQuest = new UserQuest();
        userQuest.setUserQuestUserId(leaderboardEntry.getUserId());
        userQuest.setUserQuestQuestId(leaderboardEntry.getQuestId());
        leaderboardRepository.save(userQuest);
        return new Message("Success");
    }

    @DeleteMapping("/{id}")
    public Message remEntry(@PathVariable Long id) {
        UserQuest userQuest = leaderboardRepository.findUserQuestById(id);
        if (userQuest != null) {
            leaderboardRepository.delete(userQuest);
            return new Message("Success");
        }
        return new Message("Nao existe oop");
    }
}