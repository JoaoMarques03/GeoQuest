package com.example.teste.controllers;

import com.example.teste.models.Foto;
import com.example.teste.models.Locais;
import com.example.teste.models.repository.LocaisRepository;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/locais")
@AllArgsConstructor
public class LocaisController {
    final LocaisRepository locaisRepository;

    @GetMapping()
    public Iterable<Locais> getAll() {
        return locaisRepository.findAll();
    }

    @GetMapping("/{name}")
    public Locais getByName(@PathVariable String name) {
        return locaisRepository.findLocaisByLocationName(name);
    }

    @DeleteMapping()
    public void deleteAll() {
        locaisRepository.deleteAll();
    }

    @PostMapping
    public Locais createUser(@RequestBody Locais locais) {
        locaisRepository.save(locais);
        return locais;
    }
}
