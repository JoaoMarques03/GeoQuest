package com.example.teste.controllers;

import com.example.teste.models.User;
import com.example.teste.models.repository.UserRepository;
import com.example.teste.models.requests.Message;
import com.example.teste.models.requests.UserLogin;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/login")
@AllArgsConstructor
public class LoginController {
    final UserRepository userRepository;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Message loginUser(@RequestBody UserLogin userLogin) {
        String name = userLogin.getUsername();
        String pass = userLogin.getPassword();

        User user = userRepository.findUserByUsersName(name);
        if(user != null && user.getUsersPassword() == pass) return new Message("Login OK");

        return new Message("Login oops");
    }

}