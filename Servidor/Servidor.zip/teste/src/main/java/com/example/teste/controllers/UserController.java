package com.example.teste.controllers;

import com.example.teste.models.User;
import com.example.teste.models.repository.UserRepository;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user")
@AllArgsConstructor
public class UserController {
    final UserRepository userRepository;

    @GetMapping("/all")
    public Iterable<User> getAll() {
        return userRepository.findAll();
    }

    @DeleteMapping("/all")
    public void deleteAll() {
        userRepository.deleteAll();
    }

    @GetMapping()
    public User findUserByName(@RequestParam String username) {
        System.out.println(username);
        return userRepository.findUserByUsersName(username);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public User createUser(@RequestBody User user) {
        userRepository.save(user);
        return user;
    }

    @DeleteMapping
    public void deleteUserByName(@RequestParam String username) {
        userRepository.delete(userRepository.findUserByUsersName(username));
    }
}