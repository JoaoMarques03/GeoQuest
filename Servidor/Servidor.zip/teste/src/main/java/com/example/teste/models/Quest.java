package com.example.teste.models;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.LinkedHashSet;
import java.util.Set;

@Entity
@Getter
@Setter
@Table(name = "quest")
public class Quest {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "quest_id", nullable = false)
    private Integer id;

    @Column(name = "pontuacao")
    private Integer pontuacao;

    @NotNull
    @Column(name = "localizacao", nullable = false, length = Integer.MAX_VALUE)
    private String localizacao;

    @NotNull
    @Column(name = "quest_bdate", nullable = false)
    private LocalDate questBdate;

    @NotNull
    @Column(name = "locais_encontrados", nullable = false)
    private Integer locaisEncontrados;

    @NotNull
    @Column(name = "passos_em_metros", nullable = false, precision = 6, scale = 3)
    private BigDecimal passosEmMetros;
}