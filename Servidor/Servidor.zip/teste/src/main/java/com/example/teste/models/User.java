package com.example.teste.models;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

import java.util.LinkedHashSet;
import java.util.Set;

@Entity
@Table(name = "users")
@Getter
@Setter
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "users_id", nullable = false)
    private Integer id;

    @NotNull
    @Column(name = "users_name", nullable = false, length = Integer.MAX_VALUE)
    private String usersName;

    @NotNull
    @Column(name = "users_password", nullable = false, length = Integer.MAX_VALUE)
    private String usersPassword;
}