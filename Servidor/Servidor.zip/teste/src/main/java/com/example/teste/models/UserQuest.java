package com.example.teste.models;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
@Table(name = "user_quest")
@Getter
@Setter
public class UserQuest {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_quest_id", nullable = false)
    private Integer id;

    @Column(name = "user_quest_quest_id", nullable = false)
    private Integer userQuestQuestId;

    @Column(name = "user_quest_user_id", nullable = false)
    private Integer userQuestUserId;
}