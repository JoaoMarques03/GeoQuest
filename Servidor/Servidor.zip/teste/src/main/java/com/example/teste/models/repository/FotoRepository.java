package com.example.teste.models.repository;

import com.example.teste.models.Foto;
import org.springframework.data.repository.CrudRepository;

public interface FotoRepository extends CrudRepository<Foto, Long> {
    Foto findByImageUrl(String imagem);
    Foto findByPhotoLocationId(String id);
}
