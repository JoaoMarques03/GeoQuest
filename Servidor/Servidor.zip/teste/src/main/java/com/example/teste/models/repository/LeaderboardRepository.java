package com.example.teste.models.repository;

import com.example.teste.models.UserQuest;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface LeaderboardRepository extends CrudRepository<UserQuest, Long> {

    UserQuest findUserQuestById(Long id);
    @Query(
            value = "select * from user_quest " +
                    "inner join quest on quest_id = user_quest_quest_id " +
                    "order by locais_encontrados DESC",
            nativeQuery = true)
    List<UserQuest> getLeaderboard();
}
