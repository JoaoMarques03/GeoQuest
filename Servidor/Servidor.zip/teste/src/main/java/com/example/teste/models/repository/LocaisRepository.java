package com.example.teste.models.repository;

import com.example.teste.models.Locais;
import org.springframework.data.repository.CrudRepository;

public interface LocaisRepository extends CrudRepository<Locais, Long> {
    Locais findLocaisByLocationName(String name);
}